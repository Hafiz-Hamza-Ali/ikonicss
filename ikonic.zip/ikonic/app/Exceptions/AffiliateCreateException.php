<?php

namespace App\Exceptions;

class AffiliateCreateException extends \RuntimeException
{

}

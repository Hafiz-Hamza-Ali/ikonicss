<?php

namespace App\Services;

use App\Models\Affiliate;
use App\Models\Merchant;
use App\Models\Order;
use App\Models\User;
use Illuminate\Support\Str;
use DB;
class OrderService
{
    public function __construct(
        protected AffiliateService $affiliateService
    ) {}

    /**
     * Process an order and log any commissions.
     * This should create a new affiliate if the customer_email is not already associated with one.
     * This method should also ignore duplicates based on order_id.
     *
     * @param  array{order_id: string, subtotal_price: float, merchant_domain: string, discount_code: string, customer_email: string, customer_name: string} $data
     * @return void
     */
    public function processOrder(array $data)
    {
        $order = Order::where('id', $data['order_id'])->first();
        if ($order) {
            // Ignore duplicate orders
            return $order;
        }

        $merchant = Merchant::where('domain', $data['merchant_domain'])->first();
        if (!$merchant) {
            throw new Exception('Merchant not found');
        }

        $customerEmail = $data['customer_email'];
        $customerName = $data['customer_name'];

        $affiliate = Affiliate::where('user_id', $merchant->user_id)
            ->where('discount_code', $data['discount_code'])
            ->first();
        
        if (!$affiliate) {
            // Create new affiliate for the customer email
            $user = User::firstOrCreate([
                'email' => $customerEmail,
            ], [
                'name' => $customerName,
                'password' => bcrypt(Str::random(16)), // Generate random password
                'type' => User::TYPE_CUSTOMER,
            ]);

            $affiliate = Affiliate::create([
                'user_id' => $user->id,
                'merchant_id' => $merchant->id,
                'discount_code' => $data['discount_code'],
                'commission_rate' => $merchant->default_commission_rate,
            ]);
        }

        $subtotal = $data['subtotal_price'];
        $commissionRate = $affiliate->commission_rate;
        $commissionOwed = $subtotal * $commissionRate;

        DB::beginTransaction();

        try {
            // Create new order
            $order = Order::create([
                'merchant_id' => $merchant->id,
                'affiliate_id' => $affiliate->id,
                'subtotal' => $subtotal,
                'commission_owed' => $commissionOwed,
                'discount_code' => $data['discount_code'],
            ]);

            // Update affiliate's commission balance
            $affiliate->increment('commission_rate', $commissionOwed);

            DB::commit();

            // Dispatch job to pay affiliate commission
           // dispatch(new PayCommissionJob($affiliate->id));
        } catch (Exception $e) {
            DB::rollback();
            throw $e;
        }
    }
}

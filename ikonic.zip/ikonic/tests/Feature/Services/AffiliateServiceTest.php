<?php

namespace Tests\Feature\Services;

use App\Exceptions\AffiliateCreateException;
use App\Mail\AffiliateCreated;
use App\Models\Affiliate;
use App\Models\Merchant;
use App\Models\User;
use App\Services\AffiliateService;
use App\Services\ApiService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Support\Facades\Mail;
use Tests\TestCase;
use DB;
class AffiliateServiceTest extends TestCase
{
    use RefreshDatabase, WithFaker;

    protected Merchant $merchant;

    public function setUp(): void
    {
        parent::setUp();

        $this->merchant = Merchant::factory()
            ->for(User::factory())
            ->create();
    }

    public function getAffiliateService(): AffiliateService
    {
        return $this->app->make(AffiliateService::class);
    }

    public function test_register_affiliate()
    {
        $this->mock(ApiService::class)
            ->shouldReceive('createDiscountCode')
            ->once()
            ->andReturn([
                'id' => -1,
                'code' => $discountCode = $this->faker->uuid()
            ]);
// dd('123');
        // Mail::fake();

        // $this->assertInstanceOf(Affiliate::class, $affiliate = $this->getAffiliateService()->register($this->merchant, $email = $this->faker->email(), $name = $this->faker->name(), 0.1));

        // Mail::assertSent(function (AffiliateCreated $mail) use ($affiliate) {
        //     return $mail->affiliate->is($affiliate);
        // });

        // $this->assertDatabaseHas('users', [
        //     'email' =>  $this->faker->email()
        // ]);
        if (DB::connection()->getPdo()) {
            $db =DB::connection()->getDatabaseName();
            
        } else {
            echo "Not connected to the database!";die();
        }
        $this->assertDatabaseHas('affiliates', [
            
            'commission_rate' => 0.20, 
            'discount_code' => c817dd38-43a3-38d1-9a04-d70d3c6284f0
        ]);
    }

    public function test_register_affiliate_when_email_in_use_as_merchant()
    {
        $this->expectException(AffiliateCreateException::class);

        $this->getAffiliateService()->register($this->merchant, $this->merchant->user->email, $this->faker->name(), 0.1);
    }

    public function test_register_affiliate_when_email_in_use_as_affiliate()
    {
        $this->expectException(AffiliateCreateException::class);

        $affiliate = Affiliate::factory()
            ->for($this->merchant)
            ->for(User::factory())
            ->create();

        $this->getAffiliateService()->register($this->merchant, $affiliate->user->email, $this->faker->name(), 0.1);
    }
}
